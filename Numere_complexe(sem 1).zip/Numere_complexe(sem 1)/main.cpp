#include <iostream>
#include "complexe.h"
using namespace std;

int main()
{
    complexe A;
    A.interfata();

    return 0;
}
